/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package analizador;
/*
Elizabeth Contreras Marquez
Grupo: 7ISC12
*/
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author oscar
 */
public class Separar {

    public String[] palabras() {

        Scanner teclado = new Scanner(System.in);

        System.out.println("Introduce un código");
        String texto = teclado.nextLine();

        String[] palabras = texto.split(" |; |;");
        
        return palabras;
    }
    public String[] frases() {

        Scanner teclado = new Scanner(System.in);

        System.out.println("Introduce un código");
        String texto = teclado.nextLine();

        String[] palabras = texto.split("; |;");

        return palabras;
    }
    
    
    
    
    
    
}
