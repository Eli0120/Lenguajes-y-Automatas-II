/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package analizador;
/*
Elizabeth Contreras Marquez
Grupo: 7ISC12
*/
public class Sintactico {

    
    public void palabras_reservadas(String frase){
        if (frase.matches("int [[a-zA-Z0-9_]]+")) {
            System.out.println(frase + "; - Es correcto");
        }else if (frase.matches("double [[a-zA-Z0-9_]]+")) {
            System.out.println(frase + "; - Es correcto");
        }else if (frase.matches("float [[a-zA-Z0-9_]]+")) {
            System.out.println(frase + "; - Es correcto");
        }else if (frase.matches("char [[a-zA-Z0-9_]]+")) {
            System.out.println(frase + "; - Es correcto");
        }else if (frase.matches("String [[a-zA-Z0-9_]]+")) {
            System.out.println(frase + "; - Es correcto");
        }else if(frase.matches("if+[[(]]+[[)]]+[[{]]+[[}]]+")) {
            System.out.println(" Es correcto");
        }else if(frase.matches("while+[[(]]+[[)]]+[[{]]+[[}]]+")){
            System.out.println(" Es correcto");
        }else if(frase.matches("do+[[{]]+[[}]]+while+[[(]]+[[)]]+")){
            System.out.println(" Es correcto");
        }else if(frase.matches("public void [[a-zA-Z0-9_]]+[[(]]+[[)]]+[[{]]+[[}]]+")){
            System.out.println(" Es correcto");
        }else if(frase.matches("boolean [[a-zA-Z0-9_]]+[[=]]+[[truefalse]]+")){
            System.out.println(frase + "; - Es correcto");
        }else{
            System.out.println("Es incorrecto");
        }
    }
    
   
}

