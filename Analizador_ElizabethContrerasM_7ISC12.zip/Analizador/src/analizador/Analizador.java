/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package analizador;

import java.util.ArrayList;
import java.util.Scanner;
import analizador.Lexico.*;

/*
Elizabeth Contreras Marquez
Grupo: 7ISC12
 */
public class Analizador {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int re;
        
        do {
            Scanner teclado = new Scanner(System.in);
            int opcion;
            Separar sep = new Separar();
            Sintactico sin = new Sintactico();
            System.out.println("------------ Analizador utilizando ArrayList y splitters ------------\n-------------------------- Menu principal -------------------------- \n");
            System.out.println("1. Analizador lexico \n2. Analizador sintactico \n3. Salir");
            opcion = teclado.nextInt();
            if (opcion == 1) {
                Lexico lex = new Lexico();
                for (String palabra : sep.palabras()) {
                    lex.comparartodo(palabra);
                }
            } else if (opcion == 2) {
                for (String frase : sep.frases()) {
                    sin.palabras_reservadas(frase);
                }
            } else if (opcion == 3) {
                System.exit(0);
            } else {
                System.out.println("Opcion incorrecta \nIntente nuevamente");
            }
            System.out.println("¿Desea regresar al menu de opciones? \nSi=1 \nNo=0");
            re = teclado.nextInt();
        } while (re == 1);

    }
}
