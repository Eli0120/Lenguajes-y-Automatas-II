/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package analizador;

/*
Elizabeth Contreras Marquez
Grupo: 7ISC12
 */
public class Lexico {

    public void comparartodo(String palabras) {
        this.palabras_reservadas(palabras);
        this.operadores_aritmeticos(palabras);
        this.identificador(palabras);
        this.operadores_logicos(palabras);
        this.operadores_relacionales(palabras);
    }

    public void palabras_reservadas(String palabras) {
        if (palabras.equals("int")) {
            System.out.println("Token: " + palabras + " - Es una palabra reservada");
        }
        if (palabras.equals("double")) {
            System.out.println("Token: " + palabras + " - Es una palabra reservada");
        }
        if (palabras.equals("float")) {
            System.out.println("Token: " + palabras + " - Es una palabra reservada");
        }
        if (palabras.equals("char")) {
            System.out.println("Token: " + palabras + " - Es una palabra reservada");
        }
        if (palabras.equals("String")) {
            System.out.println("Token: " + palabras + " - Es una palabra reservada");
        }
        if (palabras.equals("if")) {
            System.out.println("Token: " + palabras + " - Es una palabra reservada");
        }
        if (palabras.equals("while")) {
            System.out.println("Token: " + palabras + " - Es una palabra reservada");
        }
        if (palabras.equals("do")) {
            System.out.println("Token: " + palabras + " - Es una palabra reservada");
        }
        if (palabras.equals("for")) {
            System.out.println("Token: " + palabras + " - Es una palabra reservada");
        }
        if (palabras.equals("switch")) {
            System.out.println("Token: " + palabras + " - Es una palabra reservada");
        }
        if (palabras.equals("this")) {
            System.out.println("Token: " + palabras + " - Es una palabra reservada");
        }
        if (palabras.equals("break")) {
            System.out.println("Token: " + palabras + " - Es una palabra reservada");
        }
        if (palabras.equals("case")) {
            System.out.println("Token: " + palabras + " - Es una palabra reservada");
        }

    }

    public void operadores_aritmeticos(String palabras) {
        if (palabras.equals("-")) {
            System.out.println("Símbolo: " + palabras + " Operador aritmético");
        }
        if (palabras.equals("+")) {
            System.out.println("Símbolo: " + palabras + " Operador aritmético");
        }
        if (palabras.equals("*")) {
            System.out.println("Símbolo: " + palabras + " Operador aritmético");
        }
        if (palabras.equals("/")) {
            System.out.println("Símbolo: " + palabras + " Operador aritmético");
        }
    }

    public void identificador(String palabras) {
        if (palabras.matches("[a-zA-Z0-9_]+") && (palabras.equals("int") || palabras.equals("double") || palabras.equals("float")
                || palabras.equals("char") || palabras.equals("String") || palabras.equals("if") || palabras.equals("while")
                || palabras.equals("do") || palabras.equals("for") || palabras.equals("switch") || palabras.equals("this")
                || palabras.equals("break") || palabras.equals("case"))) {

        } else if (palabras.matches("[+-/*<>]") || palabras.matches("[=<>!]+[=]") || palabras.matches("[&|]+[&|]")) {

        }else if(palabras.matches("[0-9_]+")){
            System.out.println(palabras+ " - incorrecto");

        }else{
            System.out.println("Token: " + palabras + " - Variable");
                }

    }

    public void operadores_logicos(String palabras) {
        if (palabras.equals("<")) {
            System.out.println("Símbolo: " + palabras + " Operador lógico");
        }
        if (palabras.equals(">")) {
            System.out.println("Símbolo: " + palabras + " Operador lógico");
        }
        if (palabras.equals("==")) {
            System.out.println("Símbolo: " + palabras + " Operador lógico");
        }
        if (palabras.equals("<=")) {
            System.out.println("Símbolo: " + palabras + " Operador lógico");
        }
        if (palabras.equals(">=")) {
            System.out.println("Símbolo: " + palabras + " Operador lógico");
        }
        if (palabras.equals("!=")) {
            System.out.println("Símbolo: " + palabras + " Operador lógico");
        }
    }

    public void operadores_relacionales(String palabras) {
        if (palabras.equals("&&")) {
            System.out.println("Símbolo: " + palabras + " Operador relacional");
        }
        if (palabras.equals("||")) {
            System.out.println("Símbolo: " + palabras + " Operador relacional");
        }

    }

}
